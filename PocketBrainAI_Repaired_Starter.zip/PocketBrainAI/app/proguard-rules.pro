# Keep native inference JNI methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep Room entity classes
-keep class com.pocketbrain.ai.data.local.** { *; }

# Keep Preferences DataStore
-keep class androidx.datastore.preferences.** { *; }

# Keep ONNX Runtime GenAI and llama.cpp symbols
-keep class ai.onnxruntime.** { *; }
-keep class com.microsoft.onnxruntime.** { *; }

# Keep OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
