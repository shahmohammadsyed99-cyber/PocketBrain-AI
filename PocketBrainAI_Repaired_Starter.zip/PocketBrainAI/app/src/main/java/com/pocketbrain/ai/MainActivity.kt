package com.pocketbrain.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.pocketbrain.ai.ui.PocketBrainApp
import com.pocketbrain.ai.ui.theme.PocketBrainTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PocketBrainTheme {
                PocketBrainApp()
            }
        }
    }
}
