package com.pocketbrain.ai

import android.app.Application
import com.pocketbrain.ai.data.local.ChatDatabase
import com.pocketbrain.ai.data.preferences.SettingsDataStore
import com.pocketbrain.ai.data.engine.MemoryManager
import java.io.File

class PocketBrainApplication : Application() {

    lateinit var database: ChatDatabase
        private set

    lateinit var settingsDataStore: SettingsDataStore
        private set

    lateinit var modelsDirectory: File
        private set

    lateinit var memoryManager: MemoryManager
        private set

    override fun onCreate() {
        super.onCreate()
        
        database = ChatDatabase.getDatabase(this)
        settingsDataStore = SettingsDataStore(this)
        memoryManager = MemoryManager(this)

        // Ensure sandboxed models directory exists in app-private storage
        modelsDirectory = File(filesDir, "models").apply {
            if (!exists()) mkdirs()
        }
    }
}
