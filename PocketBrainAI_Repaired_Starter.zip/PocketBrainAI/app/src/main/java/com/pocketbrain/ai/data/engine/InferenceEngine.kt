package com.pocketbrain.ai.data.engine

import com.pocketbrain.ai.data.preferences.ModelConfig
import kotlinx.coroutines.flow.Flow
import java.io.File

data class GenerationMetrics(
    val promptTokens: Int,
    val generatedTokens: Int,
    val durationMs: Long,
    val tokensPerSecond: Float
)

interface InferenceEngine {
    val isLoaded: Boolean
    val currentModelFile: File?

    suspend fun loadModel(modelFile: File, config: ModelConfig): Result<Unit>
    suspend fun unloadModel()

    /**
     * Runs generation on background Dispatchers.Default.
     * Emits streaming tokens reactively word-by-word/token-by-token.
     */
    fun generateStreaming(
        prompt: String,
        config: ModelConfig
    ): Flow<String>
}
