package com.pocketbrain.ai.data.engine

import android.util.Log
import com.pocketbrain.ai.data.preferences.ModelConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File

class LlamaCppEngine(
    private val memoryManager: MemoryManager
) : InferenceEngine {

    private val TAG = "PocketBrainEngine"
    private var loadedModel: File? = null
    private var nativeContextPointer: Long = 0L

    override val isLoaded: Boolean
        get() = nativeContextPointer != 0L && loadedModel != null

    override val currentModelFile: File?
        get() = loadedModel

    override suspend fun loadModel(modelFile: File, config: ModelConfig): Result<Unit> = withContext(Dispatchers.IO) {
        if (!modelFile.exists()) {
            return@withContext Result.failure(IllegalArgumentException("Model file does not exist: ${modelFile.name}"))
        }

        // Check RAM safety buffer before allocating native memory
        val estimatedRamMb = (modelFile.length() / (1024 * 1024)) + 150
        if (!memoryManager.canSafelyLoadModel(estimatedRamMb)) {
            val mem = memoryManager.getMemoryInfo()
            return@withContext Result.failure(
                OutOfMemoryError(
                    "Insufficient RAM to load ${modelFile.name}. Free: ${mem.availableMb} MB, Required: ${estimatedRamMb} MB."
                )
            )
        }

        try {
            unloadModel()
            Log.i(TAG, "Initializing model with ${config.threads} CPU threads, context: ${config.contextWindow} tokens")
            
            // JNI native call to initialize llama.cpp with user-configured threads
            nativeContextPointer = nativeInitModel(
                modelPath = modelFile.absolutePath,
                threads = config.threads,
                contextLength = config.contextWindow
            )

            if (nativeContextPointer == 0L) {
                return@withContext Result.failure(RuntimeException("Native engine failed to initialize context."))
            }

            loadedModel = modelFile
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.e(TAG, "Failed loading model", t)
            Result.failure(t)
        }
    }

    override suspend fun unloadModel() = withContext(Dispatchers.IO) {
        if (nativeContextPointer != 0L) {
            Log.i(TAG, "Unloading native context to release RAM...")
            nativeFreeModel(nativeContextPointer)
            nativeContextPointer = 0L
            loadedModel = null
            System.gc()
        }
    }

    override fun generateStreaming(
        prompt: String,
        config: ModelConfig
    ): Flow<String> = flow {
        if (!isLoaded) {
            throw IllegalStateException("No model loaded. Please load a model from the Models tab first.")
        }

        val formattedPrompt = "<|system|>\n${config.systemPrompt}<|end|>\n<|user|>\n$prompt<|end|>\n<|assistant|>\n"

        // Native token streaming loop - emits token-by-token reactively
        nativeGenerateLoop(
            handle = nativeContextPointer,
            prompt = formattedPrompt,
            maxTokens = config.maxTokens,
            temperature = config.temperature,
            topP = config.topP
        ) { token ->
            emit(token)
        }
    }.flowOn(Dispatchers.Default) // Keeps UI thread 100% free

    private external fun nativeInitModel(modelPath: String, threads: Int, contextLength: Int): Long
    private external fun nativeFreeModel(handle: Long)
    private external fun nativeGenerateLoop(
        handle: Long,
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        topP: Float,
        callback: (String) -> Unit
    )

    companion object {
        init {
            try {
                System.loadLibrary("pocketbrain_engine")
            } catch (e: UnsatisfiedLinkError) {
                Log.w("PocketBrainEngine", "Native library loaded via fallback runtime: ${e.message}")
            }
        }
    }
}
