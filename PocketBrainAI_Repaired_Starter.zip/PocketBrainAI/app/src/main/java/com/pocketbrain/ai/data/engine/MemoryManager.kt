package com.pocketbrain.ai.data.engine

import android.app.ActivityManager
import android.content.Context

data class MemoryInfo(val availableMb: Long, val totalMb: Long)

class MemoryManager(context: Context) {
    private val appContext = context.applicationContext

    fun getMemoryInfo(): MemoryInfo {
        val manager = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(info)
        return MemoryInfo(
            availableMb = info.availMem / (1024L * 1024L),
            totalMb = info.totalMem / (1024L * 1024L)
        )
    }

    fun canSafelyLoadModel(estimatedRamMb: Long): Boolean {
        val info = getMemoryInfo()
        // Keep at least 700 MB available for Android and the app after loading.
        return estimatedRamMb > 0 && info.availableMb >= estimatedRamMb + 700L
    }
}
