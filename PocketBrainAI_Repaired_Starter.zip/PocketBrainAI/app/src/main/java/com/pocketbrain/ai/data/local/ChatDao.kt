package com.pocketbrain.ai.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Query("UPDATE chat_messages SET content = :newContent, tokensGenerated = :tokens, generationTimeMs = :timeMs, tokensPerSecond = :tps WHERE id = :id")
    suspend fun updateAssistantMessage(id: Long, newContent: String, tokens: Int, timeMs: Long, tps: Float)

    @Query("DELETE FROM chat_messages")
    suspend fun clearChat()

    @Query("SELECT COUNT(*) FROM chat_messages")
    suspend fun getMessageCount(): Int
}
