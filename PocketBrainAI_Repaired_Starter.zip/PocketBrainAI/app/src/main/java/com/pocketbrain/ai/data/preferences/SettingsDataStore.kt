package com.pocketbrain.ai.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "pocketbrain_settings")

data class ModelConfig(
    val maxTokens: Int = 512,
    val threads: Int = 4,
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val contextWindow: Int = 2048,
    val systemPrompt: String = "You are PocketBrain AI, a fast and helpful assistant running completely on this Android phone without internet."
)

class SettingsDataStore(private val context: Context) {

    private object PreferencesKeys {
        val KEY_MAX_TOKENS = intPreferencesKey("max_tokens")
        val KEY_THREADS = intPreferencesKey("threads")
        val KEY_TEMPERATURE = floatPreferencesKey("temperature")
        val KEY_TOP_P = floatPreferencesKey("top_p")
        val KEY_CONTEXT_WINDOW = intPreferencesKey("context_window")
        val KEY_SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
    }

    val modelConfigFlow: Flow<ModelConfig> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            val defaultCores = (Runtime.getRuntime().availableProcessors() - 1).coerceAtLeast(2)
            ModelConfig(
                maxTokens = preferences[PreferencesKeys.KEY_MAX_TOKENS] ?: 512,
                threads = preferences[PreferencesKeys.KEY_THREADS] ?: defaultCores,
                temperature = preferences[PreferencesKeys.KEY_TEMPERATURE] ?: 0.7f,
                topP = preferences[PreferencesKeys.KEY_TOP_P] ?: 0.9f,
                contextWindow = preferences[PreferencesKeys.KEY_CONTEXT_WINDOW] ?: 2048,
                systemPrompt = preferences[PreferencesKeys.KEY_SYSTEM_PROMPT] 
                    ?: "You are PocketBrain AI, a fast and helpful assistant running completely on this Android phone without internet."
            )
        }

    suspend fun updateMaxTokens(tokens: Int) {
        context.dataStore.edit { it[PreferencesKeys.KEY_MAX_TOKENS] = tokens }
    }

    suspend fun updateThreads(threads: Int) {
        context.dataStore.edit { it[PreferencesKeys.KEY_THREADS] = threads }
    }

    suspend fun updateTemperature(temp: Float) {
        context.dataStore.edit { it[PreferencesKeys.KEY_TEMPERATURE] = temp }
    }

    suspend fun updateTopP(topP: Float) {
        context.dataStore.edit { it[PreferencesKeys.KEY_TOP_P] = topP }
    }

    suspend fun updateContextWindow(ctx: Int) {
        context.dataStore.edit { it[PreferencesKeys.KEY_CONTEXT_WINDOW] = ctx }
    }

    suspend fun updateSystemPrompt(prompt: String) {
        context.dataStore.edit { it[PreferencesKeys.KEY_SYSTEM_PROMPT] = prompt }
    }

    suspend fun resetToDefaults() {
        val defaultCores = (Runtime.getRuntime().availableProcessors() - 1).coerceAtLeast(2)
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.KEY_MAX_TOKENS] = 512
            preferences[PreferencesKeys.KEY_THREADS] = defaultCores
            preferences[PreferencesKeys.KEY_TEMPERATURE] = 0.7f
            preferences[PreferencesKeys.KEY_TOP_P] = 0.9f
            preferences[PreferencesKeys.KEY_CONTEXT_WINDOW] = 2048
            preferences[PreferencesKeys.KEY_SYSTEM_PROMPT] = 
                "You are PocketBrain AI, a fast and helpful assistant running completely on this Android phone without internet."
        }
    }
}
