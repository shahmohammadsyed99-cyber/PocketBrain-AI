package com.pocketbrain.ai.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.pocketbrain.ai.ui.about.AboutScreen
import com.pocketbrain.ai.ui.chat.ChatScreen
import com.pocketbrain.ai.ui.chat.ChatViewModel
import com.pocketbrain.ai.ui.models.ModelManagerScreen
import com.pocketbrain.ai.ui.settings.SettingsScreen
import com.pocketbrain.ai.ui.settings.SettingsViewModel

sealed class Screen(val route: String, val title: String) {
    object Chat : Screen("chat", "Chat")
    object Models : Screen("models", "Models")
    object Settings : Screen("settings", "Settings")
    object About : Screen("about", "About")
}

@Composable
fun PocketBrainApp() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Chat.route

    val chatViewModel: ChatViewModel = viewModel()
    val settingsViewModel: SettingsViewModel = viewModel()

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Chat, contentDescription = "Chat") },
                    label = { Text("Chat") },
                    selected = currentRoute == Screen.Chat.route,
                    onClick = { navController.navigate(Screen.Chat.route) }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.CloudDownload, contentDescription = "Models") },
                    label = { Text("Models") },
                    selected = currentRoute == Screen.Models.route,
                    onClick = { navController.navigate(Screen.Models.route) }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") },
                    selected = currentRoute == Screen.Settings.route,
                    onClick = { navController.navigate(Screen.Settings.route) }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Info, contentDescription = "About") },
                    label = { Text("About") },
                    selected = currentRoute == Screen.About.route,
                    onClick = { navController.navigate(Screen.About.route) }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Chat.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Chat.route) {
                ChatScreen(viewModel = chatViewModel)
            }
            composable(Screen.Models.route) {
                ModelManagerScreen()
            }
            composable(Screen.Settings.route) {
                SettingsScreen(viewModel = settingsViewModel)
            }
            composable(Screen.About.route) {
                AboutScreen()
            }
        }
    }
}
