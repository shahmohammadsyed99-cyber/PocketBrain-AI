package com.pocketbrain.ai.ui.chat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pocketbrain.ai.PocketBrainApplication
import com.pocketbrain.ai.data.local.ChatMessageEntity
import com.pocketbrain.ai.data.local.MessageRole
import com.pocketbrain.ai.data.engine.InferenceEngine
import com.pocketbrain.ai.data.engine.LlamaCppEngine
import com.pocketbrain.ai.data.preferences.ModelConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ChatUiState(
    val messages: List<ChatMessageEntity> = emptyList(),
    val isGenerating: Boolean = false,
    val streamingText: String = "",
    val currentTokens: Int = 0,
    val currentTps: Float = 0f,
    val activeModelName: String? = null,
    val errorMessage: String? = null,
    val isOfflineMode: Boolean = true,
    val currentConfig: ModelConfig = ModelConfig()
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PocketBrainApplication
    private val chatDao = app.database.chatDao()
    private val settingsDataStore = app.settingsDataStore
    private val inferenceEngine: InferenceEngine = LlamaCppEngine(app.memoryManager)

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var generationJob: Job? = null

    init {
        // Collect saved messages from Room Database
        viewModelScope.launch {
            chatDao.getAllMessages().collect { savedList ->
                _uiState.value = _uiState.value.copy(messages = savedList)
            }
        }

        // Collect model configuration from DataStore
        viewModelScope.launch {
            settingsDataStore.modelConfigFlow.collect { config ->
                _uiState.value = _uiState.value.copy(currentConfig = config)
            }
        }
    }

    fun sendMessage(userText: String) {
        val trimmed = userText.trim()
        if (trimmed.isEmpty() || _uiState.value.isGenerating) return

        generationJob = viewModelScope.launch {
            // 1. Insert user query to SQLite Room Database
            val userMsg = ChatMessageEntity(
                role = MessageRole.USER,
                content = trimmed
            )
            chatDao.insertMessage(userMsg)

            // 2. Set streaming UI state
            _uiState.value = _uiState.value.copy(
                isGenerating = true,
                streamingText = "",
                currentTokens = 0,
                currentTps = 0f,
                errorMessage = null
            )

            val startTime = System.currentTimeMillis()
            val responseBuilder = StringBuilder()
            var tokenCount = 0

            try {
                // 3. Collect streaming tokens asynchronously on Dispatchers.Default
                // This updates word-by-word/token-by-token in real time!
                inferenceEngine.generateStreaming(
                    prompt = trimmed,
                    config = _uiState.value.currentConfig
                ).collect { token ->
                    responseBuilder.append(token)
                    tokenCount++
                    val elapsedSec = ((System.currentTimeMillis() - startTime) / 1000f).coerceAtLeast(0.05f)
                    val tps = tokenCount / elapsedSec

                    _uiState.value = _uiState.value.copy(
                        streamingText = responseBuilder.toString(),
                        currentTokens = tokenCount,
                        currentTps = tps
                    )
                }

                // 4. Save finished assistant response to Room Database
                val finalDuration = System.currentTimeMillis() - startTime
                val finalTps = if (finalDuration > 0) (tokenCount / (finalDuration / 1000f)) else 0f

                val assistantMsg = ChatMessageEntity(
                    role = MessageRole.ASSISTANT,
                    content = responseBuilder.toString(),
                    modelUsed = _uiState.value.activeModelName ?: "Local Small LM",
                    tokensGenerated = tokenCount,
                    generationTimeMs = finalDuration,
                    tokensPerSecond = finalTps
                )
                chatDao.insertMessage(assistantMsg)

                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    streamingText = ""
                )
            } catch (e: Exception) {
                // Handle cancellation gracefully
                if (responseBuilder.isNotEmpty()) {
                    val partialMsg = ChatMessageEntity(
                        role = MessageRole.ASSISTANT,
                        content = "${responseBuilder.toString()} [Stopped]",
                        modelUsed = _uiState.value.activeModelName ?: "Local Small LM",
                        tokensGenerated = tokenCount,
                        generationTimeMs = System.currentTimeMillis() - startTime,
                        tokensPerSecond = tokenCount / (((System.currentTimeMillis() - startTime) / 1000f).coerceAtLeast(0.1f))
                    )
                    chatDao.insertMessage(partialMsg)
                }

                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    streamingText = "",
                    errorMessage = if (e !is kotlinx.coroutines.CancellationException) e.message else null
                )
            }
        }
    }

    /**
     * Immediately stops active token generation and preserves partial response.
     */
    fun stopGeneration() {
        generationJob?.cancel()
        generationJob = null
    }

    fun clearChat() {
        viewModelScope.launch(Dispatchers.IO) {
            chatDao.clearChat()
        }
    }

    fun dismissError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
