package com.pocketbrain.ai.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    modifier: Modifier = Modifier
) {
    val config by viewModel.modelConfig.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Model Settings", fontWeight = FontWeight.Bold) },
                actions = {
                    TextButton(onClick = { viewModel.resetToDefaults() }) {
                        Text("Reset")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Setting 1: Number of CPU Threads
            SettingCard(
                title = "Inference CPU Threads: ${config.threads} / ${viewModel.maxAvailableCpuCores} Cores",
                description = "Number of CPU cores allocated for matrix multiplications during generation.",
                impact = "• Higher (4-6): Faster token generation (more tok/s), but increases phone heat and battery usage.\n• Lower (2-3): Conserves battery, prevents thermal throttling, keeps phone cooler."
            ) {
                Slider(
                    value = config.threads.toFloat(),
                    onValueChange = { viewModel.setThreads(it.roundToInt()) },
                    valueRange = 1f..viewModel.maxAvailableCpuCores.toFloat(),
                    steps = (viewModel.maxAvailableCpuCores - 2).coerceAtLeast(0)
                )
            }

            // Setting 2: Maximum Generation Length (Max Tokens)
            SettingCard(
                title = "Max Generation Length: ${config.maxTokens} Tokens",
                description = "The upper limit of tokens (words/subwords) the model will generate before stopping.",
                impact = "• Higher (1024-2048): Allows long essays, detailed code snippets, and comprehensive answers. Takes longer to finish.\n• Lower (128-512): Fast, punchy responses, saves battery, ideal for quick questions."
            ) {
                Slider(
                    value = config.maxTokens.toFloat(),
                    onValueChange = { viewModel.setMaxTokens(it.roundToInt()) },
                    valueRange = 64f..2048f,
                    steps = 15
                )
            }

            // Setting 3: Temperature (Creativity vs Determinism)
            SettingCard(
                title = "Temperature: ${String.format("%.2f", config.temperature)}",
                description = "Controls the randomness of predicted next-token probabilities.",
                impact = "• Lower (0.1 - 0.4): Factual, deterministic, consistent. Best for code, math, and fact queries.\n• Higher (0.7 - 1.0): Creative, diverse vocabulary. Higher values (>1.2) may produce gibberish."
            ) {
                Slider(
                    value = config.temperature,
                    onValueChange = { viewModel.setTemperature(it) },
                    valueRange = 0.1f..1.5f
                )
            }

            // Setting 4: Context Window Size
            SettingCard(
                title = "Context Window: ${config.contextWindow} Tokens",
                description = "How much past conversation history the model can remember at once.",
                impact = "• Higher (4096): Remembers longer chat conversations, but requires +300-500 MB more RAM.\n• Lower (1024-2048): Fits easily into budget phones with 3GB-4GB RAM without risk of OOM."
            ) {
                Slider(
                    value = config.contextWindow.toFloat(),
                    onValueChange = { viewModel.setContextWindow(it.roundToInt()) },
                    valueRange = 512f..4096f,
                    steps = 6
                )
            }

            // Setting 5: System Prompt
            SettingCard(
                title = "System Instructions",
                description = "Guides the tone, behavior, and personality of the local model.",
                impact = "Applied at the start of every session before user messages."
            ) {
                OutlinedTextField(
                    value = config.systemPrompt,
                    onValueChange = { viewModel.setSystemPrompt(it) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    minLines = 3,
                    maxLines = 5
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun SettingCard(
    title: String,
    description: String,
    impact: String,
    content: @Composable () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )
            Spacer(modifier = Modifier.height(8.dp))
            content()
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = impact,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.9f),
                    modifier = Modifier.padding(10.dp)
                )
            }
        }
    }
}
