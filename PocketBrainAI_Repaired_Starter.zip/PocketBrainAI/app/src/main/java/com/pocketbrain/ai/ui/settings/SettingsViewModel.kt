package com.pocketbrain.ai.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pocketbrain.ai.PocketBrainApplication
import com.pocketbrain.ai.data.preferences.ModelConfig
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PocketBrainApplication
    private val settingsDataStore = app.settingsDataStore

    val maxAvailableCpuCores: Int = Runtime.getRuntime().availableProcessors()

    val modelConfig: StateFlow<ModelConfig> = settingsDataStore.modelConfigFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ModelConfig()
        )

    fun setMaxTokens(tokens: Int) {
        viewModelScope.launch {
            settingsDataStore.updateMaxTokens(tokens)
        }
    }

    fun setThreads(threads: Int) {
        viewModelScope.launch {
            settingsDataStore.updateThreads(threads.coerceIn(1, maxAvailableCpuCores))
        }
    }

    fun setTemperature(temp: Float) {
        viewModelScope.launch {
            settingsDataStore.updateTemperature(temp)
        }
    }

    fun setTopP(topP: Float) {
        viewModelScope.launch {
            settingsDataStore.updateTopP(topP)
        }
    }

    fun setContextWindow(ctx: Int) {
        viewModelScope.launch {
            settingsDataStore.updateContextWindow(ctx)
        }
    }

    fun setSystemPrompt(prompt: String) {
        viewModelScope.launch {
            settingsDataStore.updateSystemPrompt(prompt)
        }
    }

    fun resetToDefaults() {
        viewModelScope.launch {
            settingsDataStore.resetToDefaults()
        }
    }
}
